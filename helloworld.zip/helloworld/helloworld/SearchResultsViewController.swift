//
//  ViewController.swift
//  helloworld
//
//  Created by Fan Zhang on 5/20/15.
//  Copyright (c) 2015 Fan Zhang. All rights reserved.
//

import UIKit


class SearchResultsViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, APIControllerProtocol{
    
    let kCellIdentifier: String = "SearchResultCell"
    
    @IBOutlet var appsTableView: UITableView!
    
    var albums = [Album]()
    
    var imageCache = [String:UIImage]()
    
    var api : APIController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        api = APIController(delegate: self)
        UIApplication.sharedApplication().networkActivityIndicatorVisible = true
        api.searchItunesFor("Skrilex")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section:    Int) -> Int {
        return albums.count
    }
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell: UITableViewCell = tableView.dequeueReusableCellWithIdentifier(kCellIdentifier) as! UITableViewCell
        let album = self.albums[indexPath.row]
        
        cell.detailTextLabel?.text = album.price
        cell.textLabel?.text = album.title
        
        cell.imageView?.image = UIImage(named: "Blank52")
        
        let thumbnailURLString = album.thumbnailImageUrl
        let thumbnailURL = NSURL(string: thumbnailURLString)!
        
        if let img = imageCache[thumbnailURLString]{
            cell.imageView?.image = img
        } else {
            let request : NSURLRequest = NSURLRequest(URL:thumbnailURL)
            let mainQueue = NSOperationQueue.mainQueue()
            NSURLConnection.sendAsynchronousRequest(request, queue: mainQueue, completionHandler: {(response,data,error) -> Void in
                
                if error == nil{
                    let image = UIImage(data:data)
                    self.imageCache[thumbnailURLString] = image
                    
                    dispatch_async(dispatch_get_main_queue(), {
                        if let cellToUpdate = tableView.cellForRowAtIndexPath(indexPath){
                            cellToUpdate.imageView?.image = image
                        }
                    })
                }
                
            })
            
            
        }
        
        return cell
    }
    
//    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
//        if let rowData = self.albums[indexPath.row] as? NSDictionary,
//            name = rowData["trackName"] as? String,
//            formattedPrice = rowData["formattedPrice"] as? String{
//                let alert = UIAlertController(title: name, message: formattedPrice, preferredStyle: .Alert)
//                alert.addAction(UIAlertAction(title: "Ok", style: .Default, handler: nil))
//                self.presentViewController(alert, animated: true, completion: nil)
//        }
//    }
    

    func didReceiveAPIResults(results: NSArray) {
        dispatch_async(dispatch_get_main_queue(), {
            self.albums = Album.albumsWithJSON(results)
            self.appsTableView!.reloadData()
            UIApplication.sharedApplication().networkActivityIndicatorVisible = false
        })
    }

}

